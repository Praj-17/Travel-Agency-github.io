// document.querySelector("header").o
// document.querySelector("h1").addClass("effects");

// document.querySelector(".header").addEventListener("onmouseover", function(){
//     document.querySelector("h1").style.visibility="visible";
// });

// $("").on("mouseover", function(){
//   $("h1").addClass("effects");
//   $("img").addClass("img-effect");
// });
